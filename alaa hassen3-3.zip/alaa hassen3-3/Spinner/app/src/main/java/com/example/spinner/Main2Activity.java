package com.example.spinner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {



    String []hotel;
    int price[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView text2=(TextView)findViewById(R.id.textView6);
        Intent in=getIntent();
        if(in.getStringExtra("City").equals("Istanbol")){
            hotel=new String[3];
            price=new int[3];
            price[0]=100;
            price[1]=150;
            price[2]=200;
            hotel[0]="Plaza";
            hotel[1]="Royal";
            hotel[2]="Grand";
        }else if(in.getStringExtra("City").equals("Paris")){
            hotel=new String[3];
            price=new int[3];
            price[0]=400;
            price[1]=50;
            price[2]=150;
            hotel[0]="paris1";
            hotel[1]="paris2";
            hotel[2]="paris3";
        }else if(in.getStringExtra("City").equals("London")){
            hotel=new String[3];
            price=new int[3];
            price[0]=100;
            price[1]=200;
            price[2]=200;
            hotel[0]="London1";
            hotel[1]="London2";
            hotel[2]="London3";
        }else if(in.getStringExtra("City").equals("Baghdad")){
            hotel=new String[3];
            price=new int[3];
            price[0]=350;
            price[1]=200;
            price[2]=400;
            hotel[0]="Babil";
            hotel[1]="Mansor";
            hotel[2]="Rasheed";
        }
        final Spinner spin=(Spinner)findViewById(R.id.spinner);
        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_item,hotel);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spin.setAdapter(aa);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView t=(TextView)findViewById(R.id.textView7);
                t.setText("Price : "+price[position]+"");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        text2.setText("City is : "+in.getStringExtra("City")+"\nRoom Type is : "+in.getStringExtra("Room"));
        // text1.get
        final Button cc=(Button) findViewById(R.id.buttt2);
        cc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent( Main2Activity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public void Clic(View view) {
        EditText edname=(EditText)findViewById(R.id.edit1);
        EditText edemail=(EditText)findViewById(R.id.edit2);
        if(edemail.getText().toString().equals("")||edname.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(),"Please Fill the text area",Toast.LENGTH_LONG).show();
        }
        else{
            Intent intent=new Intent(this,Main3Activity.class);
            intent.putExtra("Name",edname.getText().toString());
            intent.putExtra("Email",edemail.getText().toString());
            startActivity(intent);
        }

       // intent.putExtras("Name",edname.getText().toString());
       // intent.putExtras("E-mail",edname.getText().toString());
      //  startActivity(intent);

    }
}
