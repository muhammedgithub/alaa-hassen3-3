package com.example.spinner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String[] city={"Istanbol","Paris","London","Baghdad"};
    String[] roomtype={"Single","Double","Souit"};
    private RadioGroup radioGroup;
    private Button button;
    int cityPosition,roomPosition;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button=(Button) findViewById(R.id.buttt);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,Main2Activity.class);
                intent.putExtra("City",city[cityPosition]);
                intent.putExtra("Room",roomtype[roomPosition]);
                startActivity(intent);
               // intent.putExtras();
            }
        });
        final Spinner spin=(Spinner)findViewById(R.id.spinner1);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),city[position],Toast.LENGTH_LONG).show();
                cityPosition=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_item,city);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spin.setAdapter(aa);
        final Spinner spin2=(Spinner)findViewById(R.id.spinner2);
        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),roomtype[position],Toast.LENGTH_LONG).show();
                roomPosition=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter bb=new ArrayAdapter(this,android.R.layout.simple_spinner_item,roomtype);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spin2.setAdapter(bb);

    }
}
